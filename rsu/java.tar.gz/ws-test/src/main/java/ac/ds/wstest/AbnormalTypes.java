package ac.ds.wstest;

public enum AbnormalTypes {
    Collision, GasLeakage, Overturn, LowPressure, BatteryDead, OutOfGas, Burning, Engine
}
