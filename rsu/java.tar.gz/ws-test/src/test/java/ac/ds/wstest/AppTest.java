package ac.ds.wstest;

import org.junit.Test;

public class AppTest {
    @Test
    public void shouldAnswerWithTrue() throws Exception {
        // WS ws = new WS("ws://0.0.0.0:8080/mobile", "http://0.0.0.0:5122");
        // ws.TryStartUntilConnected();
        // Thread.sleep(1000 * 60);
        // ws.Stop();
        // Thread.sleep(1000 * 1);
    }
}
